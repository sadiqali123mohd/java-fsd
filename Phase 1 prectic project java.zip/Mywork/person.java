package Mywork;

public class person {
	String name;
	int age;
	String hobbie;

	person(String n, int m, String o) {
		name = n;
		age = m;
		hobbie = o;
	}

	void show() {
		System.out.println("name=" + name + " age=" + age + " Hobbie=" + hobbie);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		person p1 = new person("Gaurav", 23, "Singing");
		person p2 = new person("Saumya", 22, "Reading");

		p1.show();
		p2.show();
	}

}

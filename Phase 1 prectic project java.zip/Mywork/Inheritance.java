package Mywork;

class Earth {
	void theory() {
		System.out.println("Earth is only one planet in which the live is possible till now...");
	}
}

class water extends Earth {
	void amount() {
		System.out.println("Water is most important part of the earth");
	}
}

class land extends water {
	void place() {
		System.out.println("Land is the another important part in which human can live.");
	}
}

public class Inheritance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		land l = new land();
		l.theory();
		l.amount();
		l.place();
	}

}

package Mywork;

public class forLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for (int i = 1; i <= 10; i++) {
			int multi = i * 2;
			System.out.println(multi);
		}
	}

}

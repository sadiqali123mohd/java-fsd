package Mywork;

public class multipleCatch {
	public static void main(String args[]) {
		try {
			int[] arr = new int [5];
			System.out.println(arr[10]);
		}
		catch(ArithmeticException e) {
			System.out.println("Devided by 0 now allow");
		}
		catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("it is not allow");
		}
	}

}

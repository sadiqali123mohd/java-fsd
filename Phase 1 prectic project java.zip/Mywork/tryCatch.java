package Mywork;

public class tryCatch {

	public static void main(String[] args) {
		try {
			int a = 10 / 0;
		} catch (ArithmeticException e) {
			System.out.print("we can not devie 10 by 0 " + e);
		}
	}

}

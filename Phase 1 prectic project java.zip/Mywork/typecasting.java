package Mywork;

public class typecasting {

	public static void main(String[] args) {
		// this is implicit typecasting
		int a = 2;
		float b = a;
		System.out.println(a);
		System.out.println(b);

		// this is implicit typecasting
		double c = 25.5;
		int d = (int) c;
		System.out.println(c);
		System.out.println(d);

	}

}

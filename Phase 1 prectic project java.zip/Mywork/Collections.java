package Mywork;

import java.util.*;

public class Collections {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// creating arraylist
		System.out.println("ArrayList");
		ArrayList<String> Student = new ArrayList<String>();
		Student.add("Gaurav");//
		Student.add("Ajay");
		System.out.println(Student);

		// creating vector
		System.out.println("\n");
		System.out.println("Vector");
		Vector<Integer> s = new Vector();
		s.addElement(20);
		s.addElement(60);
		System.out.println(s);

		// creating linkedlist
		System.out.println("\n");
		System.out.println("LinkedList");
		LinkedList<String> Group = new LinkedList<String>();
		Group.add("Web development");
		Group.add("Data science");
		Iterator<String> itr = Group.iterator();
		while (itr.hasNext()) {
			System.out.println(itr.next());

			// creating hashset
			System.out.println("\n");
			System.out.println("HashSet");
			HashSet<Integer> set = new HashSet<Integer>();
			set.add(101);
			set.add(103);
			set.add(102);
			set.add(104);
			System.out.println(set);

			// creating linkedhashset
			System.out.println("\n");
			System.out.println("LinkedHashSet");
			LinkedHashSet<Integer> set2 = new LinkedHashSet<Integer>();
			set2.add(11);
			set2.add(13);
			set2.add(12);
			set2.add(14);
			System.out.println(set2);
		}
	}
}

package Mywork;

public class modifiers {
	public int a = 10;
	private int b = 20;
	protected int c = 30;
	int d = 40;

	public void publicMethod() {
		System.out.println("this is public mathod");
	}
	private void privateMethod() {
		System.out.println("this is private mathod");
	}
	protected void protectedMethod() {
		System.out.println("this is protected mathod");
	}
	void defaultMethod() {
		System.out.println("this is default method");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		modifiers obj= new modifiers();
		System.out.println("Public veriable "+ obj.a);
		System.out.println("private veriable "+ obj.b);
		System.out.println("protected veriable "+ obj.c);
		System.out.println("default veriable "+ obj.d);

		obj.privateMethod();
		obj.protectedMethod();
		obj.publicMethod();
		obj.defaultMethod();
	}

}

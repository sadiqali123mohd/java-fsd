package Mywork;

public class Finallyblock {

	public static void main(String[] args) {
		try {
			int n=25/0;
			System.out.println(n);
		}
		catch(ArithmeticException e) {
			System.out.println(e);
		}
		finally {
			System.out.println("The code is exicuted");
		}
	}

}

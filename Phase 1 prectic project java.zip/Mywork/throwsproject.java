package Mywork;

public class throwsproject {

	static void check() throws ArithmeticException {
		System.out.println("Fuction is found or not");
		throw new ArithmeticException("Mistake");
	}

	public static void main(String args[]) {
		try {
			check();
		} catch (ArithmeticException e) {
			System.out.println(e);
		}
	}
}
